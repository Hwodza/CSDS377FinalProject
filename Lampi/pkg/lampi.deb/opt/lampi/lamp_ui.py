#!/usr/bin/env python3

from lampi.lampi_app import LampiApp

if __name__ == "__main__":
    LampiApp().run()
